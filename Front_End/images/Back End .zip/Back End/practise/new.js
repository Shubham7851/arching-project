import express from 'express'
let app= express()
app.get("/", (req, res)=>{
    res.send("welcome to my page..")
})
app.get("/home", (req, res)=>{
    res.send("This is home page..")
})
app.get("/contact", (req, res)=>{
    res.send(`<p>This is the contract form.</p> 
        <input type='text' name='name'>
        <input type='submit' value='Submit'>
        `)
})
app.listen(3000, ()=>{
    console.log("your server is running..")
})