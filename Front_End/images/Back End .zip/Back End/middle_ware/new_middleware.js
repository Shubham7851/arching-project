// implement a custom middleware called uthenticcation in express that checks whether the user is an admin or not. if the URL contains ?admin=true , allow access to the /user route and print "Welcome admin" in terminal and also send the same as response on the browser. otherwise response with "your are not authenticate"
import express from 'express'
import {authentication} from './authentication'
let app = express()
app.use(express.urlencoded({extended:false}))

app.get("/", (req, res)=>{
    res.send(`
        <form action='/submit' method='POST'>
        username: <input type='text' name='username'><br>
        password: <input type='password' name='password'><br>
        <input type='submit' value='submit'>
        </form>
        `)
})
app.use(authentication)
app.post("/submit", (req, res)=>{
    res.send("Wellcome Admin!")
})
app.listen(3000)