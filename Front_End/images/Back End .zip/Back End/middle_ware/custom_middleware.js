import express from 'express'
let app=express()
let logger =(req, res, next)=>{
    console.log("Before logging")
    next()
    console.log("After logging")
}
app.use(logger)
app.get("/home", (req, res)=>{
    console.log("This is home page")
    res.end()
})
app.get("/product", (req, res)=>{
    console.log("This is product page")
    res.send()
})
app.listen(3000)
