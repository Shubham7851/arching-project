// import fs from 'fs'
// fs.readFile("sample.txt", "utf-8", (err, data)=>{
//     if(err){
//         console.log("Pizza not prepared");
//     }
//     else{
//         console.log("Pizza prepared: ", data)
//     }
// })
// console.log("Order a bottle of coke")


import fs from 'fs'
try{
    let content = fs.readFileSync("sample.txt", "utf-8")
    console.log("pizza prepared: ", content)
}
catch(err){
    console.log("Error in reading file")
}
console.log("Order a bottel of coke")