// import fs from 'fs'
// let content= "This is student data"
// fs.writeFile("storage.txt", content, (err)=>{
//     if(err){
//         console.log("Error in storing the data")
//     }
//     else{
//         console.log("Data is stored")
//     }
// })

// import fs from 'fs'
// let content= "This is student data"
// fs.writeFile("storage.txt", content,{flag:'wx'}, (err)=>{
//     if(err){
//         console.log("Error in storing the data because file already exists")
//     }
//     else{
//         console.log("Data is stored")
//     }
// })


import fs from 'fs'
let studentdata= {
    name: "Raaz",
    cgpa: 7.8,
    email: "abc@gmail.com"
}
fs.writeFile("storage.txt", JSON.stringify(studentdata, ['name', 'email', 'cgpa'], 5), (err)=>{
    if(err){
        console.log("Error in storing data")
    }
    else{
        console.log("Student data is stored")
    }
    fs.readFile("storage.txt", "utf-8", (err, data)=>{
        if(err){
            console.log("Error to fatching data")
        }
        else{
            console.log("Data featchd", data)
        }
    })
})