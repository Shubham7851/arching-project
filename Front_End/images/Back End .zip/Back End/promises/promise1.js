let x=2;
let y=3;
let result=x+y;
// async function fetchAllData(){
//     let fetchData=await fetch("https://jsonplaceholder.typicode.com/todos");
//     console.log(await fetchData.json());
// }
// fetchAllData();

fetch("https://jsonplaceholder.typicode.com/todos")
.then(data=>data.json()) //convert to json
.then(jsonData=>console.log(jsonData)) //log the json data
.catch(error=>console.error(error)); //catch and log any errors
console.log(result);