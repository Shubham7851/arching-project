import http from 'http'
import fs from 'fs'

let server= http.createServer((req, res)=>{
    if(req.url=="/home"){
        res.writeHead(200, {'content-type':'text/html'})
        res.end("<h1>Home page</h1>")
    }
    else if(req.url=="/aboutus"){
        res.writeHead(200, {'content-type':'text/html'})
        res.end("<h1>About page</h1>")
    }
    else if(req.url=="/us"){
        res.writeHead(200, {'content-type':'text/html'})
        res.write("<h1 style=color:blue>put your quqry here</h1>")
        res.end()
    }
    else{
        res.writeHead(404, {'content-type':'text/html'})
        res.end("<h2 style=color:red> Page not found</h2>")
    }
})
server.listen(3000, ()=>{
    console.log("Your server is running on port number. 3000")
})