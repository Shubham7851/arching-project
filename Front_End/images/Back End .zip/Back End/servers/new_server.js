import http from 'http'
import fs from 'fs'

const server = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/plain' });

    if (req.url === '/') {
        const currentDate = new Date().toString();
        const logMessage = `Request received on ${currentDate}\n`;
        fs.appendFile('log.txt', logMessage, (err) => {
            if (err) {
                console.error('Error writing to log file:', err);
            }
        });
        res.end('Welcome to the Home Page');
    } else if (req.url === '/about') {

        res.end('This is the About Page');

    } else if (req.url === '/contact') {

        res.end('This is the Contact Page');
    } else {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('404 - Page Not Found');
    }
});
server.listen(PORT, () => {
    console.log(`Server is running...`);
});
