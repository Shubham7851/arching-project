import http from 'http'
let server= http.createServer((req, res)=>{
    res.writeHead(200, {"content-type":"text/html"})
    res.write("<h1 style='color:red'> Hello world! This is my home page\n </h1>")
    res.write("<p>This is second line</p>")
    res.end()
})
server.listen(3000, ()=>{
    console.log("Server is listing on port no. 3000")
})