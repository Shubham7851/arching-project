import fs from 'fs'
let writestream= fs.createWriteStream("pizza.txt")
writestream.write("I need pizza\n")
writestream.write("I need another pizza")
writestream.end(()=>{
    console.log("This should be use only ")
})
writestream.on("finish", ()=>{
    conlole.log("finish writing in the file")
})