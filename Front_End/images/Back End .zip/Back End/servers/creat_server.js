import http from 'http';
import fs from 'fs';

const server=http.createServer((req, res)=>{
    fs.readFile("home.txt", "utf-8", (err, data)=>{
        if(err){
            res.writeHead({"content-type": "text/plain"})
            res.write("Error to read file...")
            res.end()
        }
        else{
            res.writeHead(200,{"content-type":"text/html"})
            res.write(`<h2 style="color:blue;">${data}</h2>`)
            res.write("file download sucessful")
            res.end()
        }
    })
})
server.listen(3000, ()=>{
    console.log("server is running in port number. 3000")
})