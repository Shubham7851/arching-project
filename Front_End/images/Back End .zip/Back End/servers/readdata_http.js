// import http from 'http'
// import fs from 'fs'
// let server= http.createServer((req, res)=>{
//     if(req.url=='/'){
//         res.writeHead(200, {'content-type': 'text/html'})
//         res.end(`
//             <h3>Click on this button to view the data</h3>
//             <a href='/feachdata'>
//             <button type='button'>View</button>
//             </a>
//             `)
//     }
//     else if(req.url=='/feachdata'){
//         fs.readFile("product.json", "utf-8", (err, data)=>{
//             if(err){
//                 res.writeHead(404, {'content-type':'text/html'})
//                 res.end("<p>No data found</p>")
//             }
//             else{
//                 let rows=''
//                 let parsedata= JSON.parse(data)
//                 for(let i=0; i<parsedata.length; i++){
//                     rows+=`
//                     <tr>
//                     <td>${parsedata[i].id}</td>
//                     <td>${parsedata[i].name}</td>
//                     <td>${parsedata[i].price}</td>
//                     </tr>
//                     `
//                 }
//                 res.writeHead(200, {'content-type':'text/html'})
//                 res.end(`
//                     <table border=1>
//                     <tr>
//                     <th>ID</th>
//                     <th>Name</th>
//                     <th>Price</th>
//                     </tr>
//                     ${rows}
//                     </table>
//                     `)
//             }
//         })
//     }
//     else{
//         res.writeHead(404, {"content-type": "text/html"})
//         res.end("<p>Page not found</p>")
//     }
// })
// server.listen(3000, ()=>{
//     console.log("your server is running on port number 3000..")
// })


import http from 'http'
import { EventEmitter } from 'events'
import fs from 'fs'
let server = http.createServer((req, res) => {
    let fileevent = new EventEmitter()
    fileevent.on("myfileevent", (parsedata) => {
        let rows=''
        for (let i = 0; i < parsedata.length; i++) {
            rows += `
                    <tr>
                    <td>${parsedata[i].id}</td>
                    <td>${parsedata[i].name}</td>
                    <td>${parsedata[i].price}</td>
                    </tr>
                    `
        }
        res.writeHead(200, { 'content-type': 'text/html' })
        res.end(`
                    <table border=1>
                    <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Price</th>
                    </tr>
                    ${rows}
                    </table>
                    `)
    })
    if (req.url == '/') {
        res.writeHead(200, { 'content-type': 'text/html' })
        res.end(`
            <h3>Click on this button to view the data</h3>
            <a href='/feachdata'>
            <button type='button'>View</button>
            </a>
            `)
    }
    else if (req.url == '/feachdata') {
        fs.readFile("product.json", "utf-8", (err, data) => {
            if (err) {
                res.writeHead(404, { 'content-type': 'text/html' })
                res.end("<p>No data found</p>")
            }
            else {
            
                let parsedata = JSON.parse(data)
                fileevent.emit("myfileevent", parsedata)
            }
        })
    }
    else {
        res.writeHead(404, { "content-type": "text/html" })
        res.end("<p>Page not found</p>")
    }
})
server.listen(3000, () => {
    console.log("your server is running on port number 3000..")
})