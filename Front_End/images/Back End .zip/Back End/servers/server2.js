import http from 'http'
import fs from 'fs'
let server = http.createServer((req, res)=>{
    if(req.url=="/read"){
        fs.readFile("data.txt", "utf-8", (err, data)=>{
            if(err){
                res.writeHead(404, {'content-type':'text/html'})
                res.write("<p style=color:red>Content you are looking for</p>")
                res.end()
            }
            else{
                res.writeHead(200, {'content-type':'text/html'})
                res.write(`<pre style=color:blue>${data}</pre>`)
                res.end()
            }
        })
    }
})
server.listen(3000, ()=>{
    console.log("Your server is running on port number 3000.")
})