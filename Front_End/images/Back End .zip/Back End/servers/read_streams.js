import fs from 'fs'
let readstrem=  fs.createReadStream("pizza.txt", {encoding:"utf-8", start:0, end:5})
readstrem.on("data", (chunk)=>{
    console.log(chunk)
})
readstrem.on("end", ()=>{
    console.log("This should be used when there is some logical ")
})
readstrem.on("error", (err)=>{
    console.log("error in reading the file")
})