import express from "express";
let app= express();
import {createServer} from "http";
import { Server } from "socket.io";
let httpServer = createServer(app);
let io = new Server(httpServer);
import path from "path";
import { fileURLToPath } from "url";
let __filename = fileURLToPath(import.meta.url);
let __dirname = path.dirname(__filename);
app.get("/",(req,res)=>{
    res.sendFile(path.join(__dirname,"client.html"));
});
io.on("connection",(socket)=>{
    console.log("a client connected");
    socket.on("message",(data)=>{
        console.log("message from client: ",data);
    });
    socket.emit("message1","Hey Client!");
    socket.on("disconnect",()=>{
        console.log("a client disconnected");
    });
});

httpServer.listen(3000,()=>{
    console.log("Server running at http://localhost:3000");
});