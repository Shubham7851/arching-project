import express from "express";
let app= express();
import {createServer} from "http";
import { Server } from "socket.io";
let http = createServer(app);
let io = new Server(http);
import path from "path";
import { fileURLToPath } from "url";
let __filename = fileURLToPath(import.meta.url);
let __dirname = path.dirname(__filename);
app.get("/",(req,res)=>{
    res.sendFile(path.join(__dirname,"chat.html"));
});
io.on("connection", (socket)=>{
    socket.on("chatmsg", (data)=>{
        io.emit("chatmsg", data)
    })
})
http.listen(3000, ()=>{
    console.log("your server is running on: http://localhost:3000")
})