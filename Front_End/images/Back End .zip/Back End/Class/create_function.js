const message=()=>{
    console.log("Hay is my first program..");
}
message()

function fun(name){
console.log(`My name is: ${name}`)
}
fun("Bipul mondal")