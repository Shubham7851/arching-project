// import * as calculate from './add.js'
// console.log(calculate.add(4,5))
// console.log(calculate.sub(6,2))

import {add, sub} from './add.js'
comsole.log(add(4,6))
comsole.log(sub(4,6))