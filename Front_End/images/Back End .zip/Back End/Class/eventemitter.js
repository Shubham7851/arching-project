// import {EventEmitter} from 'events'
// let booking = new EventEmitter()
// booking.on("newbooking", (user)=>{
//     console.log(`Ticket generated ${user}`)
// })
// booking.on("newbooking", (user)=>{
//     console.log(`Seat booked ${user}`)
// })
// booking.on("newbooking", (user, seattype)=>{
//     console.log(`Email conformation received: username: ${user}, Seat type: ${seattype}`)
// })
// booking.emit("newbooking", "sky", "VIP")
// booking.emit("newbooking", "Raaz", "regular")
// booking.emit("newbooking", "golu", "prinum")

import EventEmitter  from 'events'
function moviebooking(user, seattype) {
    let booking = new EventEmitter()
    booking.on("newbooking", (user) => {
        console.log(`Ticket generated ${user}`)
    })
    booking.on("newbooking", (user) => {
        console.log(`Seat booked ${user}`)
    })
    booking.on("newbooking", (user, seattype) => {
        console.log("Email conformation received: Username", user, "Seat type: ", seattype)
    })
    booking.emit("newbooking", user, seattype)
}
moviebooking("raaz", "VIP")
moviebooking("sky", "Regular")