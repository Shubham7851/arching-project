// import path from 'path'
// import { fileURLToPath } from 'url'
// const __filename = fileURLToPath(import.meta.url)
// console.log(import.meta.url)
// console.log(__filename)
// console.log("File name: ", path.basename(__filename))
// console.log("Directory name: ", path.dirname(__filename))
// console.log("Extention: ", path.extname(__filename))
// console.log("Path Object: ", path.parse(__filename))

//another method

import {basename, dirname, extname, parse} from 'path'
import url from 'url'
const __filename = url.fileURLToPath(import.meta.url)
console.log(import.meta.url)
console.log(__filename)
console.log(`File name:  ${basename(__filename)}`)
console.log("Directory name: ", dirname(__filename))
console.log("Extention: ", extname(__filename))
console.log("Path Object: ", parse(__filename))