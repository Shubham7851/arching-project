import EventEmitter from 'events';

let products = [
    { id: 1, name: "laptop", price: 78000, stock: 10 },
    { id: 2, name: "pc", price: 45000, stock: 8 },
    { id: 3, name: "laptop", price: 78000, stock: 3 },
];

function placeorder(user, productid, quantity) {
    const order = new EventEmitter();
    const product = products.find((p) => p.id === productid);
    // Check availability
    if (!product || product.stock < quantity) {
        console.log("Order failed");
        return;
    }
    // Email confirmation
    order.on("neworder", (user) => {
        console.log(`Email confirmation for ${user}`);
    });
    // Invoice
    order.on("neworder", (user, product, totalPrice) => {
        console.log(
            `Invoice generated for ${user} with product ${product.name} - price: ${totalPrice}`
        );
    });
    // Stock update
    order.on("neworder", (user, product) => {
        product.stock -= quantity;
        console.log(
            `Stock updated for ${product.name}, remaining stock: ${product.stock}`
        );
    });
    const totalPrice = product.price * quantity;
    order.emit("neworder", user, product, totalPrice);
}
placeorder("Ankit", 2, 5)