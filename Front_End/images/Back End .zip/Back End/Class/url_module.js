import {URL} from 'url'
const url =new URL("httlp://localhost:3000/products?id=1&name=laptop")
console.log(url)
console.log(url.pathname)