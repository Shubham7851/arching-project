import {EventEmitter} from 'events'
let myEmitter = new EventEmitter()

for (let i=0; i<25; i++){
    myEmitter.on('event', ()=>{
        console.log(i+1);
    })
}
myEmitter.emit("event");