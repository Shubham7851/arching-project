import EventEmitter from 'events';
let calpercentage = new EventEmitter();
calpercentage.on("percent", (studname, sub1, sub2, sub3, sub4, sub5) => {
    let total = sub1 + sub2 + sub3 + sub4 + sub5;
    let p = (total / 500) * 100;
    console.log(`The percentage of ${studname} is ${p}%`);
});

calpercentage.emit("percent", "Amit", 45, 78, 23, 96, 41);
calpercentage.emit("percent", "Voom", 42, 78, 36, 25, 85);
calpercentage.emit("percent", "Vamsi", 45, 73, 23, 96, 41);