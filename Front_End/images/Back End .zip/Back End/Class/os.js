import os from 'os'
console.log("operating system: ", os.platform())
console.log("Architecture: ", os.arch())
console.log("CPU core: ", os.cpus())
console.log("CPU core: ", os.cpus().length)