import express from 'express';
const app = express();
import userurls from './userroute.js';
app.use('/user', userurls);
app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});