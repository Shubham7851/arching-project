import express from 'express';
const router = express.Router();
router.get('/profile', (req, res) => {
    res.send('User route profile');
});
router.get('/settings', (req, res) => {
    res.send('User route settings');
});
export default router;