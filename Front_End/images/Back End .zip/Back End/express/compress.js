import { buffer } from 'stream/consumers'
import zlib from 'zlib'
let data= "meet me at the rastudent"
zlib.gzip(data, (err, buffer)=>{
    if(err){
        console.log("error in comprression")
    }
    else{
        console.log("The compress data is: ", buffer.toString())
    }
zlib.gunzip(buffer, (err, buffer)=>{
    if(err){
        console.log("Error in decomprecion")
    }
    else{
        console.log("decompreced data is: ",buffer.toString())
    }
})
})