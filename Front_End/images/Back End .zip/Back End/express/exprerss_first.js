import express from "express"
const app= express();
app.get("/home", (req, res)=>{
    res.send("This is home page...")
})
app.get("/content", (req, res)=>{
    res.send(`<p>This is content from </p>
        <input type="text" name="name">
        <input type="submit" value="Submit">
        `)

})
app.listen(3000, ()=>{
    console.log("http://localhost:3000/home")
});
