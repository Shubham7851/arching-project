import express from "express";
import path from "path";
import {createServer} from "http";
import {Server} from "socket.io"
import { fileURLToPath } from "url";
import { Socket } from "dgram";

let app= express();
let http = createServer(app);
let io = new Server (http);
let __filename= fileURLToPath(import.meta.url)
let __dirname= path.dirname(__filename)

app.get("/", (req, res)=>{
  res.sendFile(path.join(__dirname, "broadcast.html"));
});

let clients= 0;
io.on("connection", (socket)=>{
  clients++;
  io.emit("broadcastmsg", `${clients} are connected `)
  socket.on("disconnect", ()=>{
    clients--;
    io.emit("broadcastmsg", `${clients} are connected`)
  })
})
http.listen(3000);