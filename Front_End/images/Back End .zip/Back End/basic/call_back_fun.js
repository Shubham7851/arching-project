function fun(name, sam){
    console.log("Hi "+ name)
    sam();
}
// function boom(){console.log("good bye");}
let boom=()=>console.log("good bye")
fun("raaz", boom)