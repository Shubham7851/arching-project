const express = require("express");
const session = require("cookie-session");
const bodyParser = require("body-parser");
const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(
    session({
        name: "session",
        keys: ["nodejskey"],
        maxAge: 24 * 60 * 60 * 1000 })
);
app.get("/", (req, res) => {
    let name = req.session.name;
    let lastVisit = req.session.lastVisit;
    let message = "";
    if (name) {
        message = `<h1>Welcome, ${name}!</h1>`;
        if (lastVisit) {
            message += `<h3>Your last visit was at: ${lastVisit}</h3>`;
        }
        req.session.lastVisit = new Date().toLocaleTimeString();
    }
    res.send(`
  <html>
  <body>
  ${message}
  <form method="POST" action="/save">
  <label>Enter your name:</label>
  <input type="text" name="username" required/>
  <button type="submit">Save</button>
  </form>
  </body>
  </html>
  `);
});
app.post("/save", (req, res) => {
    req.session.name = req.body.username;
    req.session.lastVisit = new Date().toLocaleTimeString();
    res.redirect("/");
});
app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");});