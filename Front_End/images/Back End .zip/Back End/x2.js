//  Online Food Delivery System

// Design an Online Food Delivery System using Java OOP concepts. Requirements: 1. Create an
// abstract class Order with fields: customerName, amount. 2. Include abstract method placeOrder()
// and concrete method showDetails(). 3. Create interfaces: - PaymentMethod → pay(double amount)
// - DeliveryPartner → estimateDeliveryTime(int distance) - Rating → giveRating(int stars) 4.
// Implement classes: - ZomatoOrder (implements all interfaces) - SwiggyOrder (implements all
// interfaces) - LocalRestaurantOrder (implements only DeliveryPartner) 5. Use polymorphism and
// type casting in main(). 6. Demonstrate different behaviors for payment, delivery time, and rating.
// Goal: To understand abstraction, interfaces, polymorphism, and real-world system design

// abstract class  Order  -> placeOrder()   ,showDetails();
// customerName ,amount
// interaface -> PaymentMethod ,Rating,DeliveryPartner
// PaymentMethod -> abstract method-> pay(double amount)
// DeliveryPartner-> abstract method -> estimateDeliveryTime(int distance)
// Rating -> giveRating(int stars)
// three child classes
// ZomatoOrder
// SwiggyOrder
// LocalRestaurantOrder