import express from "express";
const app= express();
import path from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";
import {body, validationResult} from "express-validator";
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
app.use(express.urlencoded({extended:true}));

app.get("/",(req,res)=>{
    res.sendFile(path.join(__dirname,"./formvalidation.html"));
});
app.post("/submit",[
    body("username").notEmpty().withMessage("Username is required"),
    body("email").isEmail().withMessage("Invalid email address"),
    body("password").isLength({min:4, max:8}).withMessage("Password must be between 4 and 8 characters long")
],(req,res)=>{
    const errors = validationResult(req);
    if(!errors.isEmpty()){
        const errorMessages = errors.array().map(err=>`<li>${err.msg}</li>`).join("");
        return res.send(`<h1>Form Validation Errors</h1><ul>${errorMessages}</ul><a href="/">Go Back</a>`);
    }
    res.send(`<h1>Form Submitted Successfully</h1><p>Username: ${req.body.username}</p><p>Email: ${req.body.email}</p><a href="/">Go Back</a>`);
});
app.listen(3000,()=>{
    console.log("Server is running on http://localhost:3000");
});