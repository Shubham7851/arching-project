import express from "express"
let app=express()
import session from "express-session"
app.use(session({
    secret:"secret", 
    resave: false,
    saveUninitialized: false
}))
app.get("/login", (req, res)=>{
    req.session.user={username: "raaz", email:"raaz@gmail.com"}
    res.redirect("/dashboard")
})
app.get("/dashboard", (req, res)=>{
    if(req.session.user){
        res.send(`welcome ${req.session.user.username}`)
    }
    else{
        res.send("Please login first")
    }
})
app.get("/logout", (req, res)=>{
    if(err){
        res.send("Error in logging out")
    }
    else{
        res.send("/login")
    }
})
app.listen(3000)
