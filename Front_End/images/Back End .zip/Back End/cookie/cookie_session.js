import express from "express"
let app=express()
import cookieSession from "cookie-session"
app.use(cookieSession({
    name: "mynewsession",
    keys:['key1', 'key2'],
    maxAge:6000
}))
app.get("/login", (req, res)=>{
    req.session.username= "raaz"
    res.redirect("/dashboard")
})
app.get("/dashboard", (req, res)=>{
    if(req.session.username){
        res.send(`Welcome, ${req.session.username} This is your dashboard`)

    }
    else{
        res.send("You are required to login")
    }
})
app.listen(3000)