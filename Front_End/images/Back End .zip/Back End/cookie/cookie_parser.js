import express from 'express'
let app= express()
import cookieParser from 'cookie-parser'
app.use(cookieParser())
app.get("/setcookie", (req, res)=>{
    res.cookie("course", "node.js", {maxAge:60000})
    res.cookie("marks", 56, {maxAge:60000})
    res.send("the cookie is set")
})
app.get("/fetchcookie", (req, res)=>{
    res.send(req.cookies)
    console.log(req.cookies)
})
app.get("/deletecookie", (req, res)=>{
    res.cookie("course", "Node.js", {maxAge:-1})
    res.cookie("marks", 56, {maxAge:-1})
    res.clearCookie("coures")
    res.send("the cookie is deleted")
})
app.listen(3000,()=>{
    console.log("server is running on: http://localhost:3000")
})